<?php

/*
Plugin Name: digify
Plugin URI: digify.shop
Description: نسخه اولیه برای توسعه پلاگین ها دیجی فای جهت بهبود رضابت مشتری می باشد
Author: prime team
Version: 1.0.0
Author URI: digify.shop
*/
defined('ABSPATH') || exit;


define('digi_path', plugin_dir_path(__FILE__));

const digi_path_function= digi_path  .'function/menusetting.php' ;
const digi_path_img= digi_path .'img/digi.svg';




if (is_admin()) {
    include digi_path_function ;
}else{
}


