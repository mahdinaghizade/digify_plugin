<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<?php








function digify_menu_setting()
{
    add_menu_page("digify","digify","manage_options","digify-menu-settings","mahdi",plugins_url("digify/img/digi3.svg")  ,5);

}




function mahdi(){
    /*محل قرار گیری تب هایی که میخایم فیچر ها رو داخلش بریزم*/
?>
        <div class="wrap">
        <h1><?php esc_html_e("digify", 'text-domain'); ?></h1>
<nav>
    <div class="nav-tab-wrapper">
        <a href="#tab1" class="nav-tab nav-tab-active" id="tab1-link"><?php esc_html_e(' دیجی کالا ', 'text-domain'); ?></a>
        <a href="#tab2" class="nav-tab" id="tab2-link"><?php esc_html_e('تماس با ما چسبان', 'text-domain'); ?></a>
        <a href="#tab3" class="nav-tab" id="tab3-link"><?php esc_html_e('توابع کاربردی', 'text-domain'); ?></a>
        <a href="#tab4" class="nav-tab" id="tab4-link"><?php esc_html_e('پست کد', 'text-domain'); ?></a>

    </div>
</nav>






            <div class="tab-content">
                 <div id="tab1" class="tab-pane active">
                <h2><?php esc_html_e('اضافه کردن محصول از دیجی کالا', 'text-domain'); ?></h2>
                  <!--        ////*دیجی کالا ایمپورت علی این قسمت قرار میگیرد*///-->

                 <?php











                ?>










            </div>
                 <div id="tab2" class="tab-pane">
                   <h2>تنظیمات مروبط به شماره تماس های چسبان صفحه</h2>
                     <p> برای افزودن شماره تماس جدید روی دکمه افزودن بزنید</p>


                     <div class="tablee">
                   <table class=" table table-dark">
                       <thead>
                       <tr>

                           <td>عنوان شبکه اجتماعی</td>
                           <td>ادرس و لینک</td>
                           <td>عکس</td>
                           <td>وضعیت </td>

                       </tr>
                       </thead>
                       <tbody>
                       <tr>

                           <?php   $social_network=json_decode(get_option('social_networks'));


                           foreach($social_network as $network) {
                               echo "<tr>" ;
                               echo  "<td>  $network->name</td>";
                               echo  "<td>  $network->url_social_network</td>";

                               echo  "<td><img class='imgicon' src=" ;
                               echo  $network->image_url ;
                               echo " > </td>";

                               if ($network->active == true ){
                                   echo  "<td> فعال </td>";
                               }else{
                                    echo  "<td> غیر فعال </td>";
                               }
                               echo "</tr>" ;


                                 }



                           ?>



                       </tbody>

                   </table>
                     </div>
            <?php






            $social_networks = [
                array(
                    'name' => 'واتس آپ',
                    'url_social_network' => '09120480837' ,
                    'image_url' => 'http://mahdi.local/wp-content/uploads/2024/12/whatsapp_logo_icon_154480.webp',
                    'active' => true,
                ),
               array(
                    'name' => 'instagram',
                    'url_social_network' => '09120480837',
                    'image_url' => 'http://mahdi.local/wp-content/uploads/2024/12/Frame-1000007789.png',
                    'active' => false,
               ),
               array(
                    'name' => 'تلگرام',
                    'url_social_network' => '09120480837',
                    'image_url' => 'http://mahdi.local/wp-content/uploads/2024/12/telegram-2.png',
                    'active' => true,
               ),

            ];

             update_option('social_networks', json_encode($social_networks));

//          $json_data = json_encode($social_networks);
//          update_option('social_networksw', $json_data);
//          $mamad=get_options("social_networksw");
//          $json_encode_data =json_decode($mamad , true,"3" );
//          echo "<pre>";
//          print_r( $mamad)   ;
//          echo "</pre>";
//






/*این کار میکنه ولی دیکد نشده و اصلا کد هم نشده */


//           $social_networkss = get_option('social_networks', []);
//
//           if (!empty($social_networkss)) {
//               echo '<pre>';
//               print_r(($social_networkss)) ;
//                echo '</pre>';
//            } else {
//                echo 'چیزی اضافه نشده هنوز سیدنا.';
//            }
//
//                        ?>


                 </div>







    <div id="tab3" class="tab-pane">
        <h2><?php esc_html_e('محتوای تب ۳', 'text-domain'); ?></h2>
        <p><?php esc_html_e('این محتوای تب سوم است.', 'text-domain'); ?></p>
        <?php








        ?>
    </div>






                <div id="tab4" class="tab-pane">
                    <h2><?php esc_html_e('محتوای تب ۳', 'text-domain'); ?></h2>
                    <p><?php esc_html_e('این محتوای تب سوم است.', 'text-domain'); ?></p>
                    <?php








                    ?>
                </div>








</div>
</div>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const tabs = document.querySelectorAll('.nav-tab');
        const panes = document.querySelectorAll('.tab-pane');

        tabs.forEach(tab => {
            tab.addEventListener('click', function (e) {
                e.preventDefault();

                // فعال‌سازی تب‌ها
                tabs.forEach(t => t.classList.remove('nav-tab-active'));
                tab.classList.add('nav-tab-active');

                // فعال‌سازی محتوای مرتبط
                panes.forEach(pane => pane.classList.remove('active'));
                document.querySelector(tab.getAttribute('href')).classList.add('active');
            });
        });
    });
</script>
<style>
        .tablee{
            width: 550px;
            margin: 50px auto;

        }
    .tab-content .tab-pane { display: none; }
    .tab-content .tab-pane.active { display: block; }


.imgicon{
    width: 30px;
}


    .input-container input {
        margin-right: 10px;
        width:300px;
    }
    .input-container button {
        background: #479cff;
        border-radius: 5px;
        width: 120px;
        padding: 5px 10px;
        font-size: 16px;
        cursor: pointer;
    }

</style>

<?php

}
add_action('admin_menu','digify_menu_setting');


